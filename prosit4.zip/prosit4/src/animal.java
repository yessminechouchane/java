package entities;

public class Animal {
    private String name;
    private String species;
    private int age;

    public Animal(String name, String species, int age) {
        this.name = name;
        this.species = species;
        setAge(age); // vérifie que l’âge n’est pas négatif
    }

    public String getName() {
        return name;
    }

    public String getSpecies() {
        return species;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age >= 0) {
            this.age = age;
        } else {
            System.out.println("⚠️ Erreur : l'âge d’un animal ne peut pas être négatif !");
            this.age = 0;
        }
    }

    @Override
    public String toString() {
        return "Animal { " +
                "nom = '" + name + '\'' +
                ", espèce = '" + species + '\'' +
                ", âge = " + age +
                " }";
    }
}
