package main;

import entities.Animal;
import entities.Zoo;

public class ZooManagement {
    public static void main(String[] args) {
        Zoo zoo1 = new Zoo("Friguia Park", "Hammamet");

        Animal lion = new Animal("Simba", "Lion", 5);
        Animal girafe = new Animal("Sophie", "Girafe", 3);
        Animal oiseau = new Animal("Coco", "Perroquet", -2); // test âge négatif

        zoo1.addAnimal(lion);
        zoo1.addAnimal(girafe);
        zoo1.addAnimal(oiseau);

        zoo1.displayZoo();
    }
}
