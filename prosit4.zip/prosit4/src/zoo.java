package entities;

public class Zoo {
    private String name;
    private String city;
    private Animal[] animals;
    private int nbrAnimals;
    private final int MAX_ANIMALS = 25;

    public Zoo(String name, String city) {
        setName(name);
        this.city = city;
        this.animals = new Animal[MAX_ANIMALS];
        this.nbrAnimals = 0;
    }

    public void setName(String name) {
        if (name != null && !name.trim().isEmpty()) {
            this.name = name;
        } else {
            System.out.println("⚠️ Erreur : le nom du zoo ne doit pas être vide !");
            this.name = "Zoo sans nom";
        }
    }

    public String getName() {
        return name;
    }

    public String getCity() {
        return city;
    }

    public boolean isZooFull() {
        return nbrAnimals >= MAX_ANIMALS;
    }

    public void addAnimal(Animal a) {
        if (isZooFull()) {
            System.out.println("❌ Le zoo est plein, impossible d’ajouter : " + a.getName());
        } else {
            animals[nbrAnimals] = a;
            nbrAnimals++;
            System.out.println("✅ Animal ajouté : " + a.getName());
        }
    }

    public void displayZoo() {
        System.out.println("\n--- " + name + " (" + city + ") ---");
        for (int i = 0; i < nbrAnimals; i++) {
            System.out.println(animals[i]);
        }
        System.out.println("Nombre total d’animaux : " + nbrAnimals);
    }
}
